"""
Module that is used to run python contracts in the default way
"""

__all__ = ()

import functools
import os
import sys

sys.path.append('/')

if os.getenv('GENLAYER_ENABLE_PROFILER', 'false') == 'true':
	import cProfile

	from genlayer.vm import trace_time_micro

	p = cProfile.Profile(timer=trace_time_micro, timeunit=1_000_000)
	p.enable()

	def exit_hook():
		p.disable()
		p.create_stats()
		import base64
		import gzip
		import io
		import marshal

		stats_io = io.BytesIO()
		marshal.dump(p.stats, stats_io)
		stats_io.flush()
		stats_bytes_raw = stats_io.getvalue()
		stats_bytes_compressed = gzip.compress(stats_bytes_raw, mtime=0)

		print(
			'=== stats (gzip, base64) ===\n',
			base64.b64encode(stats_bytes_compressed).decode('ascii'),
			sep='',
			file=sys.stderr,
		)

	import atexit

	atexit.register(exit_hook)


import dataclasses
import typing

import genlayer._internal.entry_calldata as entry_calldata
import genlayer._internal.on_chain.gl_call as gl_call
import genlayer._internal.on_chain.storage  # noqa: F401  # initialize Root.MANAGER
import genlayer.calldata as calldata
import genlayer.message as gl_message
import genlayer.vm as _vm
from genlayer.vm.public_abi import EntryKind


def _give_result(res_fn: typing.Callable[[], typing.Any]) -> typing.NoReturn:
	try:
		res = res_fn()
	except _vm.UserError as r:
		gl_call.user_error(r.data)
	gl_call.contract_return(res)


def _handle_main() -> typing.NoReturn:
	import genlayer as gl_std
	import genlayer._internal.get_schema as _get_schema
	import genlayer.vm.public_abi as ABI
	from genlayer.contract import Contract

	root_slot = gl_std.storage.Root.get()

	@dataclasses.dataclass
	class MethodResolverInfo:
		selector: str
		args: list
		kwargs: dict
		msg: gl_message.MessageRawType
		contract_type: type[Contract]

	def check_abstracts(ctx: MethodResolverInfo, meth: typing.Callable) -> str | None:
		if getattr(meth, '__isabstractmethod__', False):
			return f'method is abstract `{meth}`'
		if not _get_schema._is_public(meth):
			return f'call to private method `{meth}`'
		if ctx.msg['value'] > 0 and not getattr(meth, _get_schema.PAYABLE_ATTR, False):
			return f'called non-payable method `{meth}` with non-zero value'
		return None

	def resolve_method(ctx) -> typing.Callable:
		if ctx.msg['is_init']:
			meth = getattr(__known_contract__, '__init__')
			if _get_schema._is_public(meth):
				raise TypeError('__init__ must be private')
			if meth is object.__init__:
				raise TypeError('improper contract: define __init__')

			return meth
		# now it is not init
		match ctx.selector:
			case ABI.SpecialMethod.GET_SCHEMA:
				_give_result(ctx.contract_type.__get_schema__)
			case '':
				if err := check_abstracts(ctx, ctx.contract_type.__receive__):
					if err2 := check_abstracts(
						ctx, ctx.contract_type.__handle_undefined_method__
					):
						exc = ValueError(err2)
						exc.add_note(err)
						raise exc
					else:
						contract = root_slot.get_contract_instance(ctx.contract_type)
						_give_result(
							lambda: contract.__handle_undefined_method__('', ctx.args, ctx.kwargs)
						)
				else:
					return ctx.contract_type.__receive__
			case x:
				if x.startswith('__'):
					raise ValueError('calls to methods that start with __ is forbidden')
				if x.startswith('#'):
					raise ValueError(f'unknown special method {x}')
				meth = getattr(ctx.contract_type, x, None)
				if meth is not None:
					if err := check_abstracts(ctx, meth):
						raise ValueError(err)
					return meth
				if err := check_abstracts(ctx, ctx.contract_type.__handle_undefined_method__):
					raise ValueError(err)
				contract = root_slot.get_contract_instance(ctx.contract_type)
				_give_result(
					lambda: contract.__handle_undefined_method__(
						ctx.selector, ctx.args, ctx.kwargs
					)
				)

	# load contract, it should set __known_contact__
	import contract as _user_contract_module  # noqa # pyright: ignore[reportMissingImports]
	from genlayer.contract import __known_contract__

	if __known_contract__ is None:
		raise Exception('no contract defined')

	cd_raw = calldata.decode(gl_message.raw['entry_data'])
	selector, args, kwargs = entry_calldata.normalize(cd_raw)

	if gl_message.raw.get('is_init'):
		root_slot.lock_default()

	ctx = MethodResolverInfo(selector, args, kwargs, gl_message.raw, __known_contract__)
	meth2call = resolve_method(ctx)

	contract_instance = root_slot.get_contract_instance(__known_contract__)
	_give_result(functools.partial(meth2call, contract_instance, *args, **kwargs))


if os.getenv('GENERATING_DOCS', 'false') != 'true':
	match gl_message.raw['entry_kind']:
		case EntryKind.MAIN:
			_handle_main()
		case EntryKind.SANDBOX:
			import pickle

			runner = pickle.loads(gl_message.raw['entry_data'])

			_give_result(runner)
		case EntryKind.CONSENSUS_STAGE:
			import pickle

			runner = pickle.loads(gl_message.raw['entry_data'])
			stage_data = gl_message.raw['entry_stage_data']

			_give_result(lambda: runner(stage_data))
		case x:
			raise ValueError(f'invalid entry kind {x}')
